# a Chrome extension for emojis, lenny faces, unicode emoticons

A simple chrome extension to troll your chats, jira tickets, emails, forum posts, comments...

<img src="mark/screenshot-640x400.png">

## changelog

# 1.1

* search functionality (tags, description)
* added a lot of emojis (~ 1000, had to limit to the most useful (?) ones)

See also: 
* https://github.com/Kikobeats/emojis-keywords
* https://github.com/Kikobeats/emojis-list
