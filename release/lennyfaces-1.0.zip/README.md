# lenny faces, single line ascii/unicode, dingbats

A basic chrome extension to troll your chats.


